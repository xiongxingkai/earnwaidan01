# Backers

Thank you for your supports!

* [WerGimity](https://www.patreon.com/user/creators?u=5268464)

* [Thomas_Leong](https://www.patreon.com/user/creators?u=5244543)

* [wen](https://www.patreon.com/user/creators?u=5239734)

* [Joris Vanhecke](https://www.patreon.com/user/creators?u=5145359)

* [datastream](https://www.patreon.com/user/creators?u=4315833)

* [Lê Chương](https://www.patreon.com/user/creators?u=3495305)
