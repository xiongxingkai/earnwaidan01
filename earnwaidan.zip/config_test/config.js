module.exports = {
  // BASE_API: 'http://10.0.7.132:8080',
  BASE_API: 'http://eip-dev.gcnao.cn:8080',
  REPORT_URL: 'http://eip-demo.gcnao.cn:8084',
  MAP_URL: 'http://map3.szewec.com/appmaptile',
  PLATFORM_ADMIN: 'http://10.0.8.110:8084',
  HTTPS_BASE_API: 'http://eip-dev.gcnao.cn:8080',
  // HTTPS_BASE_API: 'http://10.0.7.132:8080',
  // DEBUG_ADDRESS: '10.2.20.248'
}