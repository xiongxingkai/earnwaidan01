'use strict'
module.exports = {
  NODE_ENV: '"production"',
  // 以下为新增内容部分
  ENV_CONFIG: '"prod"'
}
