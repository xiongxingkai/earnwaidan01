const data = {
  state: {
    iconsMap: []
  },
  geterate(iconsMap) {
    this.state.iconsMap = iconsMap
  }
}
export default data